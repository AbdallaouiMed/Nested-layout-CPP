#ifndef REPORTBUG_H
#define REPORTBUG_H
#include <QWidget>
#include <QPushButton>
#include <QLabel>
#include <QLineEdit>
#include <QCheckBox>
#include<QHBoxLayout>
#include <QVBoxLayout>
#include <QCheckBox>
#include <QWidgetSet>
#include <QComboBox>
#include <QFormLayout>
#include <QTextEdit>
class reportBug : public QWidget
{
      Q_OBJECT
public:
    explicit reportBug(QWidget *parent = nullptr);


protected :
    void creatWidgets();
    void placeWidgets();
    void makeConnexions();

private:
    QTextEdit *summarytext ;
    QComboBox *Dropdown;
    QPushButton *reset;
    QPushButton *submit;
    QPushButton *dontsubmit;
    QFormLayout* Formlayout;
    QLabel *summarylabel;
    QLabel *Reproducibility;


};

#endif // REPORTBUG_H
