#include <QApplication>
#include "reportbug.h"
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    auto D = new reportBug;
    D->show();
    return a.exec();
}
