#include "reportbug.h"
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QApplication>
#include <QFormLayout>
#include <QLabel>
#include <QFormLayout>
reportBug::reportBug(QWidget *parent) : QWidget(parent)
{
creatWidgets();
placeWidgets();
makeConnexions();
setWindowTitle("Report Bug");
}

void reportBug::creatWidgets()
{
    // creatign a Qlist from the diffrent component that we have
     QStringList labels{"name","company","phone","email","problem title"};

    // creating a Text edit
     summarytext = new QTextEdit("trying to install configurayion...");

     // creating a summary & Reproducibility abel
     summarylabel = new QLabel("summary");
     Reproducibility = new QLabel("Reproducibility");

     // creating Push Butons
     reset = new QPushButton("reset");
     submit = new QPushButton("submit");
     dontsubmit =new QPushButton("don't submit");

     //creating a FormLayout
     Formlayout = new QFormLayout;

     // using a loop to add the diffrent rows of formlayout
     for (auto &lable :labels)
     {
     Formlayout->addRow(lable,new QLineEdit);
     Formlayout->setFormAlignment(Qt::AlignLeft);

//     try to impliment a if statement for sammuray

     }
     // creating a drop down
      Dropdown = new QComboBox;
      Dropdown->addItem("Always");
      Dropdown->addItem("Item 1");
      Dropdown->addItem("Item 2");


//    for (int i=0;i<7;i++) {
//        labels[i] = new QLabel;
//    }

}

void reportBug::placeWidgets()
{
    // place main layout
   auto mainlayout = new QVBoxLayout;
   this->setLayout(mainlayout);



//   placing left layout
   mainlayout->addLayout(Formlayout);
   //place sumary text edit in left layout :
   auto summarylayout= new QHBoxLayout;
   mainlayout->addLayout(summarylayout);

    //placing summary
   summarylayout->addWidget(summarylabel);
   summarylayout->addWidget(summarytext);

   //place Reproducibility
    auto myRepo = new QHBoxLayout;
    mainlayout->addLayout(myRepo);


    myRepo->addWidget(Reproducibility);
    myRepo->addWidget(Dropdown);

    auto bottom = new QHBoxLayout;
    auto Botom1 = new QHBoxLayout;
    auto Botom2 = new QHBoxLayout;

    // ading Botom2 and Botom1 to botom
    bottom->addLayout(Botom2);
    bottom->addLayout(Botom1);

    //ading bottom to main layout
    mainlayout->addLayout(bottom);

    //placing botoms widgets
     Botom2->setSpacing(200);
     Botom2 ->addWidget(reset);
     Botom2 ->addWidget(submit);
     Botom1 ->addWidget(dontsubmit);


}
void reportBug::makeConnexions()
{

}
